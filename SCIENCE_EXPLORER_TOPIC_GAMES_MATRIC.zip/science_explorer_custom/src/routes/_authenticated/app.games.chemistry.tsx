import { createFileRoute, Link, useRouteContext } from "@tanstack/react-router";
import { useState } from "react";
import { ArrowLeft } from "lucide-react";
import { AppShell, studentNav, teacherNav } from "@/components/AppShell";
import { Button } from "@/components/ui/button";
import { MoleculeBuilder } from "@/components/games/MoleculeBuilder";
import { FormulaBalancer } from "@/components/games/FormulaBalancer";
import { VirtualLab } from "@/components/games/VirtualLab";
import { useMe } from "@/lib/use-me";
export const Route = createFileRoute("/_authenticated/app/games/chemistry")({
  head: () => ({ meta: [
    { title: "Chemistry Lab — SCIENCE EXPLORER" }, { name: "description", content: "Build molecules, balance equations and explore safe virtual chemistry." },
    { property: "og:title", content: "Chemistry Lab — SCIENCE EXPLORER" }, { property: "og:description", content: "Interactive molecules, equations and simulated reactions." },
    { property: "og:type", content: "website" }, { name: "twitter:card", content: "summary" },
  ] }), component: ChemistryPage,
});
function ChemistryPage() {
  const { user } = useRouteContext({ from: "/_authenticated" });
  const role = useMe(user.id).data?.role ?? null;
  const [tab, setTab] = useState("Molecules");
  return <AppShell role={role} nav={role === "teacher" ? teacherNav : studentNav}><div className="relative isolate before:pointer-events-none before:absolute before:inset-x-[-1rem] before:-top-8 before:-z-10 before:h-[32rem] before:rounded-[3rem] before:bg-gradient-to-br before:from-cyan-500/15 before:via-emerald-400/10 before:to-transparent before:blur-2xl" data-tutor-context={`Chemistry Lab: ${tab}`}>
    <Button asChild variant="ghost" className="mb-4"><Link to="/app/games"><ArrowLeft />Back to Science Games</Link></Button>
    <h1 className="font-display text-3xl font-extrabold">Chemistry Lab</h1>
    <div className="my-5 flex flex-wrap gap-2" role="tablist">{["Molecules", "Balancing", "Virtual reactions"].map((t) => <Button role="tab" aria-selected={tab === t} key={t} variant={t === tab ? "default" : "secondary"} className="rounded-full" onClick={() => setTab(t)}>{t}</Button>)}</div>
    {tab === "Molecules" ? <MoleculeBuilder /> : tab === "Balancing" ? <FormulaBalancer /> : <VirtualLab />}
  </div></AppShell>;
}