import { createFileRoute, Link, useRouteContext } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { ArrowLeft } from "lucide-react";
import { AppShell, studentNav, teacherNav } from "@/components/AppShell";
import { Button } from "@/components/ui/button";
import { PhysicsPlaylab } from "@/components/games/PhysicsPlaylab";
import { useMe } from "@/lib/use-me";
import { supabase } from "@/integrations/supabase/client";
import { physicsProgressSlug } from "@/lib/physics-playlab";

export const Route = createFileRoute("/_authenticated/app/games/physics")({
  head: () => ({ meta: [
    { title: "Physics Playlab — SCIENCE EXPLORER" },
    { name: "description", content: "Discover gravity, motion, circuits and light in six interactive physics missions." },
    { property: "og:title", content: "Physics Playlab — SCIENCE EXPLORER" },
    { property: "og:description", content: "Play six beginner physics missions with your science buddy." },
    { property: "og:type", content: "website" }, { name: "twitter:card", content: "summary" },
  ] }), component: PhysicsPage,
});
function PhysicsPage() {
  const { user } = useRouteContext({ from: "/_authenticated" });
  const me = useMe(user.id);
  const role = me.data?.role ?? null;
  const qc = useQueryClient();
  const progress = useQuery({ queryKey: ["topic-progress", user.id], enabled: role === "student", queryFn: async () => {
    const { data, error } = await supabase.from("topic_progress").select("topic_slug,completed_at").eq("student_id", user.id);
    if (error) throw error; return data;
  } });
  const complete = async (id: string) => {
    if (role !== "student") return "Teacher practice — no student rewards saved.";
    const slug = physicsProgressSlug(id);
    const { error } = await supabase.from("topic_progress").upsert({ student_id: user.id, topic_slug: slug }, { onConflict: "student_id,topic_slug", ignoreDuplicates: true });
    if (error) throw error;
    await qc.invalidateQueries({ queryKey: ["topic-progress", user.id] });
    return "Mission saved · 25 XP for first completion only. Replays earn no extra XP.";
  };
  return <AppShell role={role} nav={role === "teacher" ? teacherNav : studentNav}>
    <div className="relative isolate before:pointer-events-none before:absolute before:inset-x-[-1rem] before:-top-8 before:-z-10 before:h-[32rem] before:rounded-[3rem] before:bg-gradient-to-br before:from-amber-500/15 before:via-blue-400/10 before:to-transparent before:blur-2xl">
    <Button asChild variant="ghost" className="mb-4 rounded-full"><Link to="/app/games"><ArrowLeft />Back to Science Games</Link></Button>
    {progress.isError && <p role="alert" className="mb-4 text-destructive">Saved missions couldn’t load. Please refresh to see your progress.</p>}
    <PhysicsPlaylab completed={(progress.data ?? []).map((p) => p.topic_slug.replace("physics-playlab-", ""))} onComplete={complete} />
    </div>
  </AppShell>;
}